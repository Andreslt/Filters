﻿namespace SQL_Server
{
    partial class NewElements
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_TbCancel = new System.Windows.Forms.Button();
            this.btn_TbCreate = new System.Windows.Forms.Button();
            this.Element = new System.Windows.Forms.Label();
            this.txt_Tablename = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.Chbx_NULL = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Chbx_PK = new System.Windows.Forms.CheckBox();
            this.txt_ColName = new System.Windows.Forms.TextBox();
            this.Cmbx_ColType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.LBx_Columns = new System.Windows.Forms.ListBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.ViewPanel = new System.Windows.Forms.Panel();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.label2 = new System.Windows.Forms.Label();
            this.Cmbx_Tables = new System.Windows.Forms.ComboBox();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_ViewName = new System.Windows.Forms.TextBox();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.Cmbx_Columns = new System.Windows.Forms.ComboBox();
            this.btn_VCreate = new System.Windows.Forms.Button();
            this.btn_VCancel = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.btn_Modify = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.ViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.Panel2.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_TbCancel
            // 
            this.btn_TbCancel.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_TbCancel.Enabled = false;
            this.btn_TbCancel.Location = new System.Drawing.Point(0, 0);
            this.btn_TbCancel.Name = "btn_TbCancel";
            this.btn_TbCancel.Size = new System.Drawing.Size(75, 31);
            this.btn_TbCancel.TabIndex = 21;
            this.btn_TbCancel.Text = "Cancel";
            this.btn_TbCancel.UseVisualStyleBackColor = true;
            this.btn_TbCancel.Click += new System.EventHandler(this.btn_Cancel2_Click);
            // 
            // btn_TbCreate
            // 
            this.btn_TbCreate.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_TbCreate.Enabled = false;
            this.btn_TbCreate.Location = new System.Drawing.Point(372, 0);
            this.btn_TbCreate.Name = "btn_TbCreate";
            this.btn_TbCreate.Size = new System.Drawing.Size(75, 31);
            this.btn_TbCreate.TabIndex = 20;
            this.btn_TbCreate.Text = "Create";
            this.btn_TbCreate.UseVisualStyleBackColor = true;
            this.btn_TbCreate.Click += new System.EventHandler(this.btn_Create2_Click);
            // 
            // Element
            // 
            this.Element.AutoSize = true;
            this.Element.Font = new System.Drawing.Font("Gadugi", 10F);
            this.Element.Location = new System.Drawing.Point(-4, 16);
            this.Element.Name = "Element";
            this.Element.Size = new System.Drawing.Size(80, 17);
            this.Element.TabIndex = 18;
            this.Element.Text = "Table Name";
            // 
            // txt_Tablename
            // 
            this.txt_Tablename.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txt_Tablename.Location = new System.Drawing.Point(0, 13);
            this.txt_Tablename.Name = "txt_Tablename";
            this.txt_Tablename.Size = new System.Drawing.Size(369, 25);
            this.txt_Tablename.TabIndex = 17;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.splitContainer4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(447, 174);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Columns";
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(3, 21);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.Chbx_NULL);
            this.splitContainer4.Panel1.Controls.Add(this.label4);
            this.splitContainer4.Panel1.Controls.Add(this.Chbx_PK);
            this.splitContainer4.Panel1.Controls.Add(this.txt_ColName);
            this.splitContainer4.Panel1.Controls.Add(this.Cmbx_ColType);
            this.splitContainer4.Panel1.Controls.Add(this.label6);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer5);
            this.splitContainer4.Size = new System.Drawing.Size(441, 150);
            this.splitContainer4.SplitterDistance = 220;
            this.splitContainer4.TabIndex = 31;
            // 
            // Chbx_NULL
            // 
            this.Chbx_NULL.AutoSize = true;
            this.Chbx_NULL.Location = new System.Drawing.Point(6, 124);
            this.Chbx_NULL.Name = "Chbx_NULL";
            this.Chbx_NULL.Size = new System.Drawing.Size(95, 21);
            this.Chbx_NULL.TabIndex = 30;
            this.Chbx_NULL.Text = "Null Values";
            this.Chbx_NULL.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 17);
            this.label4.TabIndex = 23;
            this.label4.Text = "Column Name";
            // 
            // Chbx_PK
            // 
            this.Chbx_PK.AutoSize = true;
            this.Chbx_PK.Location = new System.Drawing.Point(6, 102);
            this.Chbx_PK.Name = "Chbx_PK";
            this.Chbx_PK.Size = new System.Drawing.Size(96, 21);
            this.Chbx_PK.TabIndex = 29;
            this.Chbx_PK.Text = "PrimaryKey";
            this.Chbx_PK.UseVisualStyleBackColor = true;
            this.Chbx_PK.CheckedChanged += new System.EventHandler(this.Chbx_PK_CheckedChanged);
            // 
            // txt_ColName
            // 
            this.txt_ColName.Location = new System.Drawing.Point(6, 25);
            this.txt_ColName.Name = "txt_ColName";
            this.txt_ColName.Size = new System.Drawing.Size(203, 25);
            this.txt_ColName.TabIndex = 25;
            // 
            // Cmbx_ColType
            // 
            this.Cmbx_ColType.FormattingEnabled = true;
            this.Cmbx_ColType.Items.AddRange(new object[] {
            "Int",
            "Varchar(18)",
            "Varchar",
            "Numeric(18,5)",
            "Decimal(18,5)",
            "BigInteger"});
            this.Cmbx_ColType.Location = new System.Drawing.Point(6, 73);
            this.Cmbx_ColType.Name = "Cmbx_ColType";
            this.Cmbx_ColType.Size = new System.Drawing.Size(203, 24);
            this.Cmbx_ColType.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 17);
            this.label6.TabIndex = 27;
            this.label6.Text = "Column Type";
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.label5);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer5.Size = new System.Drawing.Size(217, 150);
            this.splitContainer5.SplitterDistance = 25;
            this.splitContainer5.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(71, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 24;
            this.label5.Text = "Resume";
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.LBx_Columns);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.btn_Add);
            this.splitContainer6.Panel2.Controls.Add(this.btn_Delete);
            this.splitContainer6.Size = new System.Drawing.Size(217, 121);
            this.splitContainer6.SplitterDistance = 92;
            this.splitContainer6.TabIndex = 0;
            // 
            // LBx_Columns
            // 
            this.LBx_Columns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LBx_Columns.FormattingEnabled = true;
            this.LBx_Columns.ItemHeight = 16;
            this.LBx_Columns.Location = new System.Drawing.Point(0, 0);
            this.LBx_Columns.Name = "LBx_Columns";
            this.LBx_Columns.Size = new System.Drawing.Size(217, 92);
            this.LBx_Columns.TabIndex = 22;
            // 
            // btn_Add
            // 
            this.btn_Add.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_Add.Location = new System.Drawing.Point(171, 0);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(46, 25);
            this.btn_Add.TabIndex = 26;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_Delete.Location = new System.Drawing.Point(0, 0);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(55, 25);
            this.btn_Delete.TabIndex = 30;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // ViewPanel
            // 
            this.ViewPanel.Controls.Add(this.splitContainer7);
            this.ViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ViewPanel.Location = new System.Drawing.Point(3, 3);
            this.ViewPanel.Name = "ViewPanel";
            this.ViewPanel.Size = new System.Drawing.Size(447, 251);
            this.ViewPanel.TabIndex = 23;
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.splitContainer8);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.splitContainer11);
            this.splitContainer7.Size = new System.Drawing.Size(447, 251);
            this.splitContainer7.SplitterDistance = 56;
            this.splitContainer7.TabIndex = 26;
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.splitContainer9);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.splitContainer10);
            this.splitContainer8.Size = new System.Drawing.Size(447, 56);
            this.splitContainer8.SplitterDistance = 25;
            this.splitContainer8.TabIndex = 0;
            // 
            // splitContainer9
            // 
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.label2);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.Cmbx_Tables);
            this.splitContainer9.Size = new System.Drawing.Size(447, 25);
            this.splitContainer9.SplitterDistance = 77;
            this.splitContainer9.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gadugi", 8F);
            this.label2.Location = new System.Drawing.Point(3, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 14);
            this.label2.TabIndex = 23;
            this.label2.Text = "Table Name";
            // 
            // Cmbx_Tables
            // 
            this.Cmbx_Tables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cmbx_Tables.Font = new System.Drawing.Font("Gadugi", 10F);
            this.Cmbx_Tables.FormattingEnabled = true;
            this.Cmbx_Tables.Location = new System.Drawing.Point(0, 0);
            this.Cmbx_Tables.Name = "Cmbx_Tables";
            this.Cmbx_Tables.Size = new System.Drawing.Size(366, 24);
            this.Cmbx_Tables.TabIndex = 0;
            this.Cmbx_Tables.SelectedIndexChanged += new System.EventHandler(this.Cmbx_Tables_SelectedIndexChanged);
            // 
            // splitContainer10
            // 
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer10.Location = new System.Drawing.Point(0, 0);
            this.splitContainer10.Name = "splitContainer10";
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.txt_ViewName);
            this.splitContainer10.Size = new System.Drawing.Size(447, 27);
            this.splitContainer10.SplitterDistance = 77;
            this.splitContainer10.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gadugi", 8F);
            this.label1.Location = new System.Drawing.Point(7, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 14);
            this.label1.TabIndex = 18;
            this.label1.Text = "View Name";
            // 
            // txt_ViewName
            // 
            this.txt_ViewName.Dock = System.Windows.Forms.DockStyle.Top;
            this.txt_ViewName.Font = new System.Drawing.Font("Gadugi", 10F);
            this.txt_ViewName.Location = new System.Drawing.Point(0, 0);
            this.txt_ViewName.Multiline = true;
            this.txt_ViewName.Name = "txt_ViewName";
            this.txt_ViewName.Size = new System.Drawing.Size(366, 26);
            this.txt_ViewName.TabIndex = 17;
            // 
            // splitContainer11
            // 
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            this.splitContainer11.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.splitContainer12);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.btn_VCreate);
            this.splitContainer11.Panel2.Controls.Add(this.btn_VCancel);
            this.splitContainer11.Panel2.Font = new System.Drawing.Font("Gadugi", 10F);
            this.splitContainer11.Size = new System.Drawing.Size(447, 191);
            this.splitContainer11.SplitterDistance = 26;
            this.splitContainer11.TabIndex = 0;
            // 
            // splitContainer12
            // 
            this.splitContainer12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer12.Location = new System.Drawing.Point(0, 0);
            this.splitContainer12.Name = "splitContainer12";
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer12.Panel2
            // 
            this.splitContainer12.Panel2.Controls.Add(this.Cmbx_Columns);
            this.splitContainer12.Size = new System.Drawing.Size(447, 26);
            this.splitContainer12.SplitterDistance = 77;
            this.splitContainer12.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Gadugi", 7F);
            this.label3.Location = new System.Drawing.Point(1, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Select Columns";
            // 
            // Cmbx_Columns
            // 
            this.Cmbx_Columns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cmbx_Columns.Font = new System.Drawing.Font("Gadugi", 10F);
            this.Cmbx_Columns.FormattingEnabled = true;
            this.Cmbx_Columns.Location = new System.Drawing.Point(0, 0);
            this.Cmbx_Columns.Name = "Cmbx_Columns";
            this.Cmbx_Columns.Size = new System.Drawing.Size(366, 24);
            this.Cmbx_Columns.TabIndex = 1;
            // 
            // btn_VCreate
            // 
            this.btn_VCreate.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_VCreate.Enabled = false;
            this.btn_VCreate.Location = new System.Drawing.Point(372, 0);
            this.btn_VCreate.Name = "btn_VCreate";
            this.btn_VCreate.Size = new System.Drawing.Size(75, 161);
            this.btn_VCreate.TabIndex = 20;
            this.btn_VCreate.Text = "Create";
            this.btn_VCreate.UseVisualStyleBackColor = true;
            this.btn_VCreate.Click += new System.EventHandler(this.btn_Createview_Click);
            // 
            // btn_VCancel
            // 
            this.btn_VCancel.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_VCancel.Enabled = false;
            this.btn_VCancel.Location = new System.Drawing.Point(0, 0);
            this.btn_VCancel.Name = "btn_VCancel";
            this.btn_VCancel.Size = new System.Drawing.Size(75, 161);
            this.btn_VCancel.TabIndex = 21;
            this.btn_VCancel.Text = "Cancel";
            this.btn_VCancel.UseVisualStyleBackColor = true;
            this.btn_VCancel.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Gadugi", 10F);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(461, 286);
            this.tabControl1.TabIndex = 24;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(453, 257);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Create Table";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Size = new System.Drawing.Size(447, 251);
            this.splitContainer1.SplitterDistance = 38;
            this.splitContainer1.TabIndex = 27;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.Element);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.txt_Tablename);
            this.splitContainer2.Size = new System.Drawing.Size(447, 38);
            this.splitContainer2.SplitterDistance = 74;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.btn_Modify);
            this.splitContainer3.Panel2.Controls.Add(this.btn_TbCancel);
            this.splitContainer3.Panel2.Controls.Add(this.btn_TbCreate);
            this.splitContainer3.Size = new System.Drawing.Size(447, 209);
            this.splitContainer3.SplitterDistance = 174;
            this.splitContainer3.TabIndex = 0;
            // 
            // btn_Modify
            // 
            this.btn_Modify.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_Modify.Enabled = false;
            this.btn_Modify.Location = new System.Drawing.Point(297, 0);
            this.btn_Modify.Name = "btn_Modify";
            this.btn_Modify.Size = new System.Drawing.Size(75, 31);
            this.btn_Modify.TabIndex = 22;
            this.btn_Modify.Text = "Modify";
            this.btn_Modify.UseVisualStyleBackColor = true;
            this.btn_Modify.Visible = false;
            this.btn_Modify.Click += new System.EventHandler(this.btn_Modify_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ViewPanel);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(453, 257);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Create View";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // NewElements
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 286);
            this.Controls.Add(this.tabControl1);
            this.Name = "NewElements";
            this.Text = "NewElements";
            this.groupBox1.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.ViewPanel.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel1.PerformLayout();
            this.splitContainer10.Panel2.ResumeLayout(false);
            this.splitContainer10.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel1.PerformLayout();
            this.splitContainer12.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button btn_TbCancel;
        public System.Windows.Forms.Button btn_TbCreate;
        public System.Windows.Forms.Label Element;
        public System.Windows.Forms.TextBox txt_Tablename;
        public System.Windows.Forms.Panel ViewPanel;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btn_VCreate;
        public System.Windows.Forms.Button btn_VCancel;
        public System.Windows.Forms.TextBox txt_ViewName;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txt_ColName;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.CheckBox Chbx_PK;
        public System.Windows.Forms.ComboBox Cmbx_ColType;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button btn_Add;
        public System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        public System.Windows.Forms.CheckBox Chbx_NULL;
        public System.Windows.Forms.ListBox LBx_Columns;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.SplitContainer splitContainer12;
        public System.Windows.Forms.ComboBox Cmbx_Tables;
        public System.Windows.Forms.ComboBox Cmbx_Columns;
        public System.Windows.Forms.Button btn_Modify;
    }
}